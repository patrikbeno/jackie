# *** Do not remove this! ***
# Although being empty, the presence of this file is important for plugins
# working correctly.


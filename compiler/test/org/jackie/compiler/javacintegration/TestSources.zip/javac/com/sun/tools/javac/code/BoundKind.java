/**
 * @(#)BoundKind.java	1.7 05/11/17
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Use and Distribution is subject to the Java Research License available
 * at <http://wwws.sun.com/software/communitysource/jrl.html>.
 */

package javac.com.sun.tools.javac.code;

import javac.com.sun.tools.javac.util.Version;

@Version("@(#)BoundKind.java	1.7 05/11/17")
public enum BoundKind {
    EXTENDS("? extends "),
    SUPER("? super "),
    UNBOUND("?");

    private final String name;

    BoundKind(String name) {
	this.name = name;
    }

    public String toString() { return name; }
}

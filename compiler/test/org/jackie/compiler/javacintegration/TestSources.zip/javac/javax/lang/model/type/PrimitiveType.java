/*
 * @(#)PrimitiveType.java	1.3 06/07/31
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package javac.javax.lang.model.type;


/**
 * Represents a primitive type.  These include
 * {@code boolean}, {@code byte}, {@code short}, {@code int},
 * {@code long}, {@code char}, {@code float}, and {@code double}.
 * 
 * @author Joseph D. Darcy
 * @author Scott Seligman
 * @author Peter von der Ah&eacute;
 * @version 1.3 06/07/31
 * @since 1.6
 */
public interface PrimitiveType extends TypeMirror {
}

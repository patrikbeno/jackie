/**
 * @(#)ClientCodeException.java	1.2 06/02/13
 *
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Use and Distribution is subject to the Java Research License available
 * at <http://wwws.sun.com/software/communitysource/jrl.html>.
 */

package javac.com.sun.tools.javac.util;

/**
 * An exception used for propogating exceptions found in client code
 * invoked from javac.
 *
 *  <p><b>This is NOT part of any API supported by Sun Microsystems.  If
 *  you write code that depends on this, you do so at your own risk.
 *  This code and its internal interfaces are subject to change or
 *  deletion without notice.</b>
 */
@Version("@(#)ClientCodeException.java	1.2 06/02/13")
public class ClientCodeException extends RuntimeException {

    static final long serialVersionUID = -5674494409392415163L;

    public ClientCodeException(Throwable cause) {
	super(cause);
    }
}

/**
 * @(#)EndPosParser.java	1.7 06/06/20
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Use and Distribution is subject to the Java Research License available
 * at <http://wwws.sun.com/software/communitysource/jrl.html>.
 *
 * @author Peter von der Ah\u00e9
 */

package javac.com.sun.tools.javac.parser;

import java.util.Map;
import java.util.HashMap;
import javac.com.sun.tools.javac.tree.JCTree;
import javac.com.sun.tools.javac.tree.TreeInfo;
import javac.com.sun.tools.javac.util.Version;

import static javac.com.sun.tools.javac.tree.JCTree.*;

/**
 * This class is similar to Parser except that it stores ending
 * positions for the tree nodes.
 *
 * <p><b>This is NOT part of any API supported by Sun Microsystems.
 * If you write code that depends on this, you do so at your own risk.
 * This code and its internal interfaces are subject to change or
 * deletion without notice.</b></p>
 */
@Version("@(#)EndPosParser.java	1.7 06/06/20")
public class EndPosParser extends Parser {

    public EndPosParser(Factory fac, Lexer S, boolean keepDocComments) {
	super(fac, S, keepDocComments);
	this.S = S;
	endPositions = new HashMap<JCTree,Integer>();
    }

    private Lexer S;

    /** A hashtable to store ending positions
     *  of source ranges indexed by the tree nodes.
     *  Defined only if option flag genEndPos is set.
     */
    Map<JCTree, Integer> endPositions;

    /** {@inheritDoc} */
    @Override
    protected void storeEnd(JCTree tree, int endpos) {
        int errorEndPos = getErrorEndPos();
	endPositions.put(tree, errorEndPos > endpos ? errorEndPos : endpos);
    }

    /** {@inheritDoc} */
    @Override
    protected <T extends JCTree> T to(T t) {
	storeEnd(t, S.endPos());
	return t;
    }

    /** {@inheritDoc} */
    @Override
    protected <T extends JCTree> T toP(T t) {
	storeEnd(t, S.prevEndPos());
	return t;
    }

    @Override
    public JCCompilationUnit compilationUnit() {
	JCCompilationUnit t = super.compilationUnit();
	t.endPositions = endPositions;
	return t;
    }

    /** {@inheritDoc} */
    @Override
    JCExpression parExpression() {
	int pos = S.pos();
	JCExpression t = super.parExpression();
	return toP(F.at(pos).Parens(t));
    }

    /** {@inheritDoc} */
    @Override
    public int getEndPos(JCTree tree) {
        return TreeInfo.getEndPos(tree, endPositions);
    }

}

/**
 * @(#)BaseFileObject.java	1.6 06/06/25
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Use and Distribution is subject to the Java Research License available
 * at <http://wwws.sun.com/software/communitysource/jrl.html>.
 */

package javac.com.sun.tools.javac.util;

import javac.javax.lang.model.element.Modifier;
import javac.javax.lang.model.element.NestingKind;
import javac.javax.tools.JavaFileObject;
import static javac.javax.tools.JavaFileObject.Kind.*;

@Version("@(#)BaseFileObject.java	1.6 06/06/25")
public abstract class BaseFileObject implements JavaFileObject {

    public JavaFileObject.Kind getKind() {
	String n = getName();
	if (n.endsWith(CLASS.extension))
	    return CLASS;
	else if (n.endsWith(SOURCE.extension))
	    return SOURCE;
	else if (n.endsWith(HTML.extension))
	    return HTML;
	else 
	    return OTHER;
    }

    @Override
    public String toString() {
	return getPath();
    }

    /** @deprecated see bug 6410637 */
    @Deprecated
    public String getPath() {
	return getName();
    }

    /** @deprecated see bug 6410637 */
    @Deprecated
    abstract public String getName();

    public NestingKind getNestingKind() { return null; }

    public Modifier getAccessLevel()  { return null; }

}

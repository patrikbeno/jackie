/*
 * @(#)Version.java	1.2 05/11/17
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package javac.com.sun.tools.javac.util;

import java.lang.annotation.*;

/**
 * Used to provide version info for a class.
 */
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.TYPE)
@Version("@(#)Version.java	1.2 05/11/17")
public @interface Version {
    String value();
}

/*
 * @(#)JavacTrees.java	1.8 06/06/26
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Use and Distribution is subject to the Java Research License available
 * at <http://www.sun.com/software/communitysource/jrl.html>.
 */

package javac.com.sun.tools.javac.api;

import java.io.IOException;
import java.util.Map;
import javac.javax.annotation.processing.ProcessingEnvironment;
import javac.javax.lang.model.element.AnnotationMirror;
import javac.javax.lang.model.element.AnnotationValue;
import javac.javax.lang.model.element.Element;
import javac.javax.lang.model.element.ExecutableElement;
import javac.javax.lang.model.element.TypeElement;
import javac.javax.lang.model.type.DeclaredType;
import javac.javax.lang.model.type.TypeMirror;
import javac.javax.tools.JavaCompiler;
import javac.javax.tools.JavaFileObject;

import javac.com.sun.source.tree.CompilationUnitTree;
import javac.com.sun.source.tree.Scope;
import javac.com.sun.source.tree.Tree;
import javac.com.sun.source.util.SourcePositions;
import javac.com.sun.source.util.TreePath;
import javac.com.sun.source.util.Trees;
import javac.com.sun.tools.javac.code.Symbol.ClassSymbol;
import javac.com.sun.tools.javac.code.Symbol.TypeSymbol;
import javac.com.sun.tools.javac.code.Symbol;
import javac.com.sun.tools.javac.comp.Attr;
import javac.com.sun.tools.javac.comp.AttrContext;
import javac.com.sun.tools.javac.comp.Enter;
import javac.com.sun.tools.javac.comp.Env;
import javac.com.sun.tools.javac.comp.MemberEnter;
import javac.com.sun.tools.javac.comp.Resolve;
import javac.com.sun.tools.javac.model.JavacElements;
import javac.com.sun.tools.javac.processing.JavacProcessingEnvironment;
import javac.com.sun.tools.javac.tree.JCTree.*;
import javac.com.sun.tools.javac.tree.JCTree;
import javac.com.sun.tools.javac.tree.TreeCopier;
import javac.com.sun.tools.javac.tree.TreeInfo;
import javac.com.sun.tools.javac.tree.TreeMaker;
import javac.com.sun.tools.javac.util.Context;
import javac.com.sun.tools.javac.util.List;
import javac.com.sun.tools.javac.util.Log;
import javac.com.sun.tools.javac.util.Pair;

/**
 * Provides an implementation of Trees.
 *
 * <p><b>This is NOT part of any API supported by Sun Microsystems.
 * If you write code that depends on this, you do so at your own
 * risk.  This code and its internal interfaces are subject to change
 * or deletion without notice.</b></p>
 *
 * @author Peter von der Ah&eacute;
 */
public class JavacTrees extends Trees {
    
    private final Resolve resolve;
    private final Enter enter;
    private final Log log;
    private final MemberEnter memberEnter;
    private final Attr attr;
    private final TreeMaker treeMaker;
    private final JavacElements elements;
    private final JavacTaskImpl javacTaskImpl;
    
    public static JavacTrees instance(JavaCompiler.CompilationTask task) {
        if (!(task instanceof JavacTaskImpl))
            throw new IllegalArgumentException();
        return instance(((JavacTaskImpl)task).getContext());
    }
    
    public static JavacTrees instance(ProcessingEnvironment env) {
        if (!(env instanceof JavacProcessingEnvironment))
            throw new IllegalArgumentException();
        return instance(((JavacProcessingEnvironment)env).getContext());
    }
    
    public static JavacTrees instance(Context context) {
        JavacTrees instance = context.get(JavacTrees.class);
        if (instance == null)
            instance = new JavacTrees(context);
        return instance;
    }
    
    private JavacTrees(Context context) {
        context.put(JavacTrees.class, this);
        attr = Attr.instance(context);
        enter = Enter.instance(context);
        elements = JavacElements.instance(context);
        log = Log.instance(context);
        resolve = Resolve.instance(context);
        treeMaker = TreeMaker.instance(context);
        memberEnter = MemberEnter.instance(context);
        javacTaskImpl = context.get(JavacTaskImpl.class);
    }
    
    public SourcePositions getSourcePositions() {
	return new SourcePositions() {    
		public long getStartPosition(CompilationUnitTree file, Tree tree) {
		    return TreeInfo.getStartPos((JCTree) tree);
		}

		public long getEndPosition(CompilationUnitTree file, Tree tree) {
		    Map<JCTree,Integer> endPositions = ((JCCompilationUnit) file).endPositions;
		    return TreeInfo.getEndPos((JCTree) tree, endPositions);
		}
	    };
    }

    public JCClassDecl getTree(TypeElement element) {
        return (JCClassDecl) getTree((Element) element);
    }
    
    public JCMethodDecl getTree(ExecutableElement method) {
        return (JCMethodDecl) getTree((Element) method);
    }
    
    public JCTree getTree(Element element) {
        Symbol symbol = (Symbol) element;
        TypeSymbol enclosing = symbol.enclClass();
        Env<AttrContext> env = enter.getEnv(enclosing);
        if (env == null)
            return null;
        JCClassDecl classNode = env.enclClass;
        if (classNode != null) {
            if (TreeInfo.symbolFor(classNode) == element)
                return classNode;
            for (JCTree node : classNode.getMembers())
                if (TreeInfo.symbolFor(node) == element)
                    return node;
        }
        return null;
    }
    
    public JCTree getTree(Element e, AnnotationMirror a) {
        return getTree(e, a, null);
    }
    
    public JCTree getTree(Element e, AnnotationMirror a, AnnotationValue v) {
        Pair<JCTree, JCCompilationUnit> treeTopLevel = elements.getTreeAndTopLevel(e, a, v);
        if (treeTopLevel == null)
            return null;
        return treeTopLevel.fst;
    }

    public TreePath getPath(CompilationUnitTree unit, Tree node) {
        return TreePath.getPath(unit, node);
    }
    
    public TreePath getPath(Element e) {
        return getPath(e, null, null);
    }
    
    public TreePath getPath(Element e, AnnotationMirror a) {
        return getPath(e, a, null);
    }
    
    public TreePath getPath(Element e, AnnotationMirror a, AnnotationValue v) {
        final Pair<JCTree, JCCompilationUnit> treeTopLevel = elements.getTreeAndTopLevel(e, a, v);
        if (treeTopLevel == null)
            return null;
        return TreePath.getPath(treeTopLevel.snd, treeTopLevel.fst);
    }
    
    public Element getElement(TreePath path) {
        Tree t = path.getLeaf();
        return TreeInfo.symbolFor((JCTree) t);
    }
    
    public TypeMirror getTypeMirror(TreePath path) {
        Tree t = path.getLeaf();
        return ((JCTree)t).type;
    }
    
    public JavacScope getScope(TreePath path) {
        return new JavacScope(getAttrContext(path));
    }

    public boolean isAccessible(Scope scope, TypeElement type) {
        if (scope instanceof JavacScope && type instanceof ClassSymbol) {
            Env<AttrContext> env = ((JavacScope) scope).env;
            return resolve.isAccessible(env, (ClassSymbol)type);
        } else
            return false;
    }
    
    public boolean isAccessible(Scope scope, Element member, DeclaredType type) {
        if (scope instanceof JavacScope 
                && member instanceof Symbol 
                && type instanceof javac.com.sun.tools.javac.code.Type) {
            Env<AttrContext> env = ((JavacScope) scope).env;
	    return resolve.isAccessible(env, (javac.com.sun.tools.javac.code.Type)type, (Symbol)member);
        } else 
            return false;
    }
    
    private Env<AttrContext> getAttrContext(TreePath path) {
        if (!(path.getLeaf() instanceof JCTree))  // implicit null-check
            throw new IllegalArgumentException();
        
        // if we're being invoked via from a JSR199 client, we need to make sure
        // all the classes have been entered; if we're being invoked from JSR269,
        // then the classes will already have been entered.
        if (javacTaskImpl != null) {
            try {
                javacTaskImpl.enter(null);
            } catch (IOException e) {
                throw new Error("unexpected error while entering symbols: " + e); 
            }
        }
        
        
        JCCompilationUnit unit = (JCCompilationUnit) path.getCompilationUnit();
        Copier copier = new Copier(treeMaker.forToplevel(unit));
        
        Env<AttrContext> env = null;
        JCMethodDecl method = null;
        JCVariableDecl field = null;
        
        List<Tree> l = List.nil();
        TreePath p = path;
        while (p != null) {
            l = l.prepend(p.getLeaf());
            p = p.getParentPath();
        }
        
        for ( ; l.nonEmpty(); l = l.tail) {
            Tree tree = l.head;
            switch (tree.getKind()) {
                case COMPILATION_UNIT:
//                    System.err.println("COMP: " + ((JCCompilationUnit)tree).sourcefile);
                    env = enter.getTopLevelEnv((JCCompilationUnit)tree);
                    break;
                case CLASS:
//                    System.err.println("CLASS: " + ((JCClassDecl)tree).sym.getSimpleName());
                    env = enter.getClassEnv(((JCClassDecl)tree).sym);
                    break;
                case METHOD:
//                    System.err.println("METHOD: " + ((JCMethodDecl)tree).sym.getSimpleName());
                    method = (JCMethodDecl)tree;
                    break;
                case VARIABLE:
//                    System.err.println("FIELD: " + ((JCVariableDecl)tree).sym.getSimpleName());
                    field = (JCVariableDecl)tree;
                    break;
                case BLOCK: {
//                    System.err.println("BLOCK: ");
                    if (method != null)
                        env = memberEnter.getMethodEnv(method, env);
                    JCTree body = copier.copy((JCTree)tree, (JCTree) path.getLeaf());
                    env = attribStatToTree(body, env, copier.leafCopy);
                    return env;
                }
                default:
//                    System.err.println("DEFAULT: " + tree.getKind());
                    if (field != null && field.getInitializer() == tree) {
                        env = memberEnter.getInitEnv(field, env);
                        JCExpression expr = copier.copy((JCExpression)tree, (JCTree) path.getLeaf());
                        env = attribExprToTree(expr, env, copier.leafCopy);
                        return env;
                    }
            }
        }
        return field != null ? memberEnter.getInitEnv(field, env) : env;
    }
    
    private Env<AttrContext> attribStatToTree(JCTree stat, Env<AttrContext>env, JCTree tree) {
        JavaFileObject prev = log.useSource(env.toplevel.sourcefile);
        try {
            return attr.attribStatToTree(stat, env, tree);
        } finally {
            log.useSource(prev);
        }
    }
    
    private Env<AttrContext> attribExprToTree(JCExpression expr, Env<AttrContext>env, JCTree tree) {
        JavaFileObject prev = log.useSource(env.toplevel.sourcefile);
        try {
            return attr.attribExprToTree(expr, env, tree);
        } finally {
            log.useSource(prev);
        }
    }
    
    /**
     * Makes a copy of a tree, noting the value resulting from copying a particular leaf.
     **/
    static class Copier extends TreeCopier<JCTree> {
        JCTree leafCopy = null;
        
        Copier(TreeMaker M) {
            super(M);
        }
        
        public <T extends JCTree> T copy(T t, JCTree leaf) {
            T t2 = super.copy(t, leaf);
            if (t == leaf)
                leafCopy = t2;
            return t2;
        }
    }
}

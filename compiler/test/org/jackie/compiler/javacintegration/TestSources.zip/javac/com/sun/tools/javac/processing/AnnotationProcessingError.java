/**
 * @(#)AnnotationProcessingError.java	1.2 05/11/17
 *
 * Copyright 2006 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 * Use and Distribution is subject to the Java Research License available
 * at <http://wwws.sun.com/software/communitysource/jrl.html>.
 */

package javac.com.sun.tools.javac.processing;

import javac.com.sun.tools.javac.util.Version;

/** 
 * Error thrown for problems encountered during annotation processing.
 *
 * <p><b>This is NOT part of any API supported by Sun Microsystems.
 * If you write code that depends on this, you do so at your own risk.
 * This code and its internal interfaces are subject to change or
 * deletion without notice.</b>
 */
@Version("@(#)AnnotationProcessingError.java	1.2 05/11/17")
public class AnnotationProcessingError extends Error {
    static final long serialVersionUID = 305337707019230790L;
    AnnotationProcessingError(Throwable cause) {
	super(cause);
    }
}

package javac;

import javac.com.sun.tools.javac.code.Symbol;
import javac.javax.tools.JavaFileObject;

/**
 * @author Patrik Beno
 */
public interface WriteCallback {

   JavaFileObject write(Symbol.ClassSymbol clssymbol);

}
